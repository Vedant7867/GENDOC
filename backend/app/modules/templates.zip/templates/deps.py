"""The ONLY file that touches teammates' code.

`install()` (see __init__.py) stores two provider callables here, so this
module never imports the auth or database modules of the main app.

Auth provider contract: an async/sync FastAPI dependency returning the current
user as either a dict or an object exposing `id`, `clubId` (or `club_id`) and
`role` ("Club Member" | "Core Coordinator" | "Club Admin" | "Faculty Advisor").
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from fastapi import Depends

from .errors import TemplateError

_providers: dict[str, Callable[..., Any]] = {}
ADMIN_ROLE = "Club Admin"


def configure(*, get_db: Callable, get_current_user: Callable) -> None:
    _providers["get_db"] = get_db
    _providers["get_current_user"] = get_current_user


@dataclass(frozen=True)
class Caller:
    id: str
    club_id: str
    role: str
    name: str = ""


def _pick(u: Any, *names: str, default: Any = None) -> Any:
    for n in names:
        v = u.get(n) if isinstance(u, dict) else getattr(u, n, None)
        if v is not None:
            return v
    return default


async def _call(name: str, *args):
    import inspect

    fn = _providers.get(name)
    if fn is None:
        raise RuntimeError("templates module not configured: call templates.install(...)")
    res = fn(*args)
    return await res if inspect.isawaitable(res) else res


async def db_dep():
    return await _call("get_db")


def make_caller_dependency():
    """Build a dependency that wraps the app's own `get_current_user`."""
    inner = _providers["get_current_user"]

    async def dep(user=Depends(inner)) -> Caller:
        if user is None:
            raise TemplateError(401, "unauthenticated", "Authentication required")
        return Caller(
            id=str(_pick(user, "id", "_id", default="")),
            club_id=str(_pick(user, "clubId", "club_id", default="")),
            role=str(_pick(user, "role", default="")),
            name=str(_pick(user, "name", default="")),
        )

    return dep
